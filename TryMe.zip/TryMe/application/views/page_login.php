
  <html ng-app="MyApplication">
  <head>
  <script src="<?php echo base_url('asset/angularjs/angular.min.js')?>"></script>
  <script src="<?php echo base_url('asset/angularjs/angular-sanitize.min.js') ?>"></script>
  <!-- <script src="<?php echo base_url('folder/app.js')?>"></script> -->
  <link rel="stylesheet" href="<?php echo base_url('folder/login_style.css')?>">
<script type="text/javascript">
  var BASEURL='<?php echo base_url();?>';
</script>

  
  </head>
 
  <body>
  
        <di ng-controller="Controller1">

            <form>
                  <div class="login-box">
                       <h2>Login</h2>
                      <form>
                          <div class="user-box">
                            <input type="username" name="username" required="">
                            <label>Username</label>
                          </div>

                          <div class="user-box">
                            <input type="password" name="password" required="">
                            <label>Password</label>
                          </div>

                          <a href="<?php echo base_url('patients/view-patient');?>">Submit</a>
                             
                          
                      </form>
                  </div>

            </form>

        </div>

  </body>
</html>

    

      



       