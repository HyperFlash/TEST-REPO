
  <html ng-app="MyApplication">
  <head>
  <script src="<?php echo base_url('asset/angularjs/angular.min.js')?>"></script>
  <script src="<?php echo base_url('asset/angularjs/angular-sanitize.min.js') ?>"></script>
  <script src="<?php echo base_url('folder/app.js')?>"></script>
  <link rel="stylesheet" href="<?php echo base_url('folder/style_table.css')?>">
<script type="text/javascript">
  var BASEURL='<?php echo base_url();?>';
</script>

  
  </head>
 
  <body>


 

<div ng-controller="Controller1" ng-init="Init('<?php echo $id; ?>')">
        

        <form ng-submit="SUBMITFORM()" autocomplete="off">



        <a class="button" href="<?php echo base_url('patients/view-patient');?>"> VIEW DATA</a>





        <div class="tabset">
          <!-- Tab 1 -->
          <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked>
          <label for="tab1">Personal Information</label>
          <!-- Tab 2 -->
          <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
          <label for="tab2">Family Information</label>
          <!-- Tab 3 -->
          <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
          <label for="tab3">PHIC Information</label>
          
          <div class="tab-panels">
            <section id="marzen" class="tab-panel">
              <!-- <h2>6A. Märzen</h2> -->
                  <div class="card">

                      <div class="head">
                        <h1>Patient information</h1>
                      </div>

                      <div class="container">
                        <table>
                              
                              <tr>
                                <td>Lastname:<input type="text" name="LASTNAME" ng-model="FORM.LASTNAME"required="required"></td>


                                <td>Firstname:<input type="text" name="FIRSTNAME" ng-model="FORM.FIRSTNAME"required="required">
                                </td>


                                <td>Middlename:<input type="text"  name="MIDDLENAME" ng-model="FORM.MIDDLENAME" required="required"></td> 


                                <td>Suffix:<input type="text" name="SUFFIX" ng-model="FORM.SUFFIX" required="required"></td>


                              </tr>
                              <tr>


                                <td>Sex: 
                                      <select ng-model="FORM.SEX" name="SEX" required="required">
                                      <option value="male">Male</option>
                                      <option value="female">Female</option>
                                     </select>
                                 </td>

                                  <td>Civil Status:
                                    <select ng-model="FORM.CIVIL_STATUS" name="CIVIL_STATUS"required="required">
                                      <option value="single">Single</option>
                                      <option value="married">Married</option>
                                      <option value="child">Child</option>
                                      <option value="separated">Separated</option>
                                      <option value="widow">Widow</option>
                                     </select>
                                 </td>


                                     <td>DOB:
                                  <input ng-model="FORM.DATE_OF_BIRTH"type="date" anme="DATE_OF_BIRTH" >
                                 </td>


                                  <td>NB Condition:<input type="text" name="NBCONDITION" ng-model="FORM.NBCONDITION" required="required"></td>
                                  </td>
                               

                                
                              </tr>

                               <tr>
                                <td>File No.:<input ng-model="FORM.FILE_NO"  type="text" name="FILE_NO" required="required"></td>

                                <td>Date Reg.:<input type="date" name="DATEREG" ng-model="FORM.DATEREG" required="required"></td>

                                 <td>Occupation:<input type="text"  name="OCCUPATION" ng-model="FORM.OCCUPATION" required="required"></td>

                                 
                                 <td>Religion: 
                                    <select ng-model="FORM.RELIGION" required="required">
                                      <option value="UP">UNITED PENTECOSTAL</option>
                                      <option value="SDA">SEVENTH DAY ADVENTIST</option>
                                      <option value="ISLAM">ISLAM</option>
                                      <option value="AGLIPAYAN">AGLIPAYAN</option>
                                      <option value="UCCP">UCCP</option>
                                      <option value="INC">IGLESIA NI CRISTO</option>
                                      <option value="PENTECOST">PENTECOST</option>
                                      <option value="MORMONS">LATER DAY SAINTS(MORMONS)</option>
                                    </select>
                                  </td>
                                 
                                
                              </tr>

                               <tr>
                                 
                                  <td>Nationality:
                                    <select ng-model="FORM.NATIONALITY" name="NATIONALITY" required="required">
                                      <option value="japaness">Japaness</option>
                                      <option value="filipino">Filipino</option>
                                      <option value="american">American</option>
                                    </select>
                                 </td>   

                                 <td>Tel no.:<input type="text" name="TELNO" ng-model="FORM.TELNO" required="required"></td> 

                                 <td>Place of Birth:<input ng-model="FORM.PLACE_BIRTH" type="text" name="PLACE_BIRTH" required="required"></td>
                                  
                              </tr>

                        </table> 

                      </div>


                  </div>


                  <div class="card">

                      <div class="head">
                        <h1>Complete Address</h1>
                      </div>

                      <div class="container">
                        <table>     
                        
                              <tr>
                                <td>No. Street:<input type="text" name="NO_STREET" ng-model="FORM.NO_STREET" ></td>


                                <td>Province:<input type="text" name="PROVINCE" ng-model="FORM.PROVINCE"></td>

                                <td>City Municipality:<input type="text" name="CITY_MUNICIPALITY" ng-model="FORM.CITY_MUNICIPALITY" ></td>
                               

                              </tr>
                              <tr>  

                                <td>Barangay:<input type="text"  name="BARANGAY" ng-model="FORM.BARANGAY" ></td>
                                 
                                 <td>Zipcode:<input type="text" name="ZIPCODE" ng-model="FORM.ZIPCODE" ></td>
                                
                              </tr>
                        </table>
                        
                         </table>

                      </div>


                  </div>



                  <div class="card">

                      <div class="head">
                        <h1>Others</h1>
                      </div>

                      <div class="container">
                         <table>      
                            
                              <tr>
                                <td>Company:<input type="text" name="COMPANY" ng-model="FORM.COMPANY" autocomplete="off"></td>

                                 <td>Address:<input type="text" name="ADDRESS" ng-model="FORM.ADDRESS" autocomplete="off"></td>

                                 <td>Health Insurance:<input type="text" name="HEALTH_INSURANCE" ng-model="FORM.HEALTH_INSURANCE"></td>


                                  <td>Address:<input type="text" name="HEALTH_INSURANCE_ADDRESS" ng-model="FORM.HEALTH_INSURANCE_ADDRESS"></td>


                              </tr>
                              <tr>
                                 <td>Credit Limit:<input type="text" name="CREDIT_LIMIT" ng-model="FORM.CREDIT_LIMIT" autocomplete="off"></td>

                                 <td>Senior Citizen No.:<input type="text" name="SENIOR_CITIZEN_NUMBER" ng-model="FORM.SENIOR_CITIZEN_NUMBER"></td>


                                 <td>Medicare: <input type="checkbox" ng-model="check" />
                                    <select ng-model="FORM.MEDICARE" name="MEDICARE" required="required" ng-disabled="!(check)">
                                      <option value="NON MEDICARE">NON MEDICARE</option>
                                      <option value="GOVERNMENT MEMBER">GOVERNMENT MEMBER</option>
                                      <option value="GOVERNMENT DEPENDENT">GOVERNMENT DEPENDENT</option>
                                      <option value="PRIVATE MEMBER">PRIVATE MEMBER</option>
                                      <option value="PRIVATE DEPENDENT">PRIVATE DEPENDENT</option>
                                      <option value="OWWA MEMBER">OWWA MEMBER</option>
                                      <option value="OWWA DEPENDENT">OWWA DEPENDENT</option>
                                      <option value="INDIGENT MEMBER">INDIGENT MEMBER</option>
                                      <option value="INDIGENT DEPENDENT">INDIGENT DEPENDENT</option>
                                      <option value="SELF-EMPLOYED MEMBER">SELF-EMPLOYED MEMBER</option>
                                      <option value="SELF-EMPLOYED DEPENDENT">SELF-EMPLOYED DEPENDENT</option>
                                      <option value="NON-PAYING MEMBER">NON-PAYING MEMBER</option>
                                      <option value="NON-PAYING DEPENDENT">NON-PAYING DEPENDENT</option>
                                      <option value="SPONSORED MEMBER">SPONSORED MEMBER</option>
                                      <option value="SPONSORED DEPENDENT">SPONSORED DEPENDENT</option>
                                      <option value="SENIOR CITIZEN MEMBER">SENIOR CITIZEN MEMBER</option>
                                      <option value="SENIOR CITIZEN DEPENT">SENIOR CITIZEN DEPENT</option>
                                      <option value="MIGRANT MEMBER">MIGRANT MEMBER</option>
                                      <option value="MIGRANT DEPENDENT">MIGRANT DEPENDENT</option>
                                      <option value="INFORMAL MEMBER">INFORMAL MEMBER</option>
                                      <option value="INFORMAL DEPENDENT">INFORMAL DEPENDENT</option>
                                      <option value="LIFETIME MEMBER">LIFETIME MEMBER</option>
                                      <option value="LIFETIME DEPENDENT">LIFETIME DEPENDENT</option>
                                    </select>



                                </td>

                                
                              </tr>

                               <tr>

                                  <td>Plan:<input type="text" name="PLAN" ng-model="FORM.PLAN" ></td>

                                 <td>Blood Type:<input type="text" name="BLOOD_TYPE" ng-model="FORM.BLOOD_TYPE"></td>

                                  <td>RH:<input type="text" name="RH" ng-model="FORM.RH"></td>
                                 
                              </tr>

                                <tr>
                                
                                 <td>Allergies:<input type="text" name="ALLERGIES" ng-model="FORM.ALLERGIES"></td>

                                    <td>SC Date Issue:<input ng-model="FORM.SC_DATE_ISSUE"type="date" name="SC_DATE_ISSUE"></td>
                              </tr>


                         </table>

                      </div>


                  </div>










                  

               
          </section>
            <section id="rauchbier" class="tab-panel">
             
             <table>
                            <tr>
                              <th>Patient's Father</th>
                            </tr>
                            <tr> 
                              <td>Father name:<input type="text" name="FATHER_NAME" ng-model="FORM.FATHER_NAME"></td>

                              <td>Address:<input type="text" name="FATHER_ADDRESS" ng-model="FORM.FATHER_ADDRESS"></td>

                              <td>Telephone No:<input type="text" name="FATHER_TELEPHONE_NO" ng-model="FORM.FATHER_TELEPHONE_NO"></td>
                              

                            </tr>
                          

                              <tr>
                              <th>Mother's Father</th>
                            </tr>
                            <tr>
                              <td>Mother name:<input type="text" name="MOTHER_NAME" ng-model="FORM.MOTHER_NAME"></td>
                              <td>Address:<input type="text" name="MOTHER_ADDRESS" ng-model="FORM.MOTHER_ADDRESS"></td>
                              
                              <td>Telephone No:<input type="text" name="MOTHER_TELEPHONE_NO" ng-model="FORM.MOTHER_TELEPHONE_NO"></td>

                            </tr>
                           

                             <tr>
                              <th>Patient's Spouse</th>
                            </tr>
                            
                               <tr>
                              <td>Spouse name:<input type="text" name="SPOUSE_NAME" ng-model="FORM.SPOUSE_NAME"></td>
                              <td>Address:<input type="text" name="SPOUSE_ADDRESS" ng-model="FORM.SPOUSE_ADDRESS"></td>

                            </tr>
                            <tr>
                              <td>Telephone No:<input type="text" name="SPOUSE_TELEPHONE_NO" ng-model="FORM.SPOUSE_TELEPHONE_NO"></td>
                              <td>Occupation:<input type="text" name="SPOUSE_OCCUPATION" ng-model="FORM.SPOUSE_OCCUPATION"></td>
                              

                              
                            </tr>

                             <tr>
                              <th>In-case of Emergency</th>
                            </tr>
                            
                               <tr>
                              <td>Emergency name:<input type="text" name="EMERGENCY_NAME" ng-model="FORM.EMERGENCY_NAME"></td>
                              <td>Address:<input type="text" name="EMERGENCY_ADDRESS" ng-model="FORM.EMERGENCY_ADDRESS"></td>

                            </tr>
                            <tr>
                              <td>Relation:
                                <!-- <input type="text" name="EMERGENCY_RELATION" ng-model="FORM.EMERGENCY_RELATION"> -->

                              <select ng-model="FORM.EMERGENCY_RELATION" name="EMERGENCY_RELATION" required="required">
                                      <option value="NON MEDICARE">AUNT</option>
                                      <option value="GOVERNMENT MEMBER">BESTFRIEND</option>
                                      <option value="GOVERNMENT DEPENDENT">BOYFRIEND</option>
                                      <option value="PRIVATE MEMBER">BROTHER</option>
                                      <option value="PRIVATE DEPENDENT">SISTER</option>
                                      <option value="OWWA MEMBER">CO-EMPOLYEE</option>
                                      <option value="OWWA DEPENDENT">COUSIN</option>
                                      <option value="INDIGENT MEMBER">DAUGHTER</option>
                                      <option value="INDIGENT DEPENDENT">SON</option>
                                      <option value="SELF-EMPLOYED MEMBER">DAUGHTER-IN-LAW</option>
                                      <option value="SELF-EMPLOYED DEPENDENT">SON-IN-LAW</option>
                                      <option value="NON-PAYING MEMBER">FATHER-IN-LAW</option>
                                      <option value="NON-PAYING DEPENDENT">MOTHER-IN-LAW</option>
                                      <option value="SPONSORED MEMBER">GIRLFRIEND</option>
                                      <option value="SPONSORED DEPENDENT">GRANDMOTHER</option>
                                      <option value="SENIOR CITIZEN MEMBER">GRANDFATHER</option>
                                      <option value="SENIOR CITIZEN DEPENT">GUARDIAN</option>
                                      <option value="MIGRANT MEMBER">HUSBAND</option>
                                      <option value="MIGRANT DEPENDENT">WIFE</option>
                                    </select>



                              </td>
                              <td>Telephone No:<input type="text" name="EMERGENCY_TELEPHONE_NO" ng-model="FORM.EMERGENCY_TELEPHONE_NO">
                              </td>
                             
                            </tr>


                             <tr>
                              <th>Patient's Employer</th>
                            </tr>
                            
                               <tr>
                              <td>Employer Name:<input type="text" name="PE_EMPLOYER_NAME" ng-model="FORM.PE_EMPLOYER_NAME"></td>
                              <td>Address:<input type="text" name="PE_ADDRESS" ng-model="FORM.PE_ADDRESS"></td>
                              <td>Telephone No:<input type="text" name="PE_TELEPHONE_NO" ng-model="FORM.PE_TELEPHONE_NO"></td>

                            </tr>
                            

                          </table> 
            </section>
            <section id="dunkles" class="tab-panel">
             <table>
                            <tr>
                              <th>Name of Member and Identification</th>
                            </tr>
                            <tr>
                              <td>Phic No.:<input type="text" name="MI_PHIC_NO" ng-model="FORM.MI_PHIC_NO"></td>

                            </tr>

                            <tr>
                             <td>Lastname.:<input type="text" name="MI_LASTNAME" ng-model="FORM.MI_LASTNAME"></td>

                              <td>Firstname.:<input type="text" name="MI_FIRSTNAME" ng-model="FORM.MI_FIRSTNAME"></td>

                              <td>Middlename.:<input type="text" name="MI_MIDDLENAME" ng-model="FORM.MI_MIDDLENAME"></td>

                              <td>Suffix.:<input type="text" name="MI_SUFFIX" ng-model="FORM.MI_SUFFIX"></td>

                            </tr>

                            <tr>
                             <td>Sex.:<input type="text" name="MI_SEX" ng-model="FORM.MI_SEX"></td>

                              <td>DOB.:<input type="text" name="MI_DOB" ng-model="FORM.MI_DOB"></td>

                              <td>Member Relation.:<input type="text" name="MI_MEMBER_RELATION" ng-model="FORM.MI_MEMBER_RELATION"></td>
                             
                            </tr>

                            <tr>
                             <td>Membership Type:<input type="text" name="MI_MEMBERSHIP_TYPE" ng-model="FORM.MI_MEMBERSHIP_TYPE"></td>

                              <td>Email.:<input type="text" name="MI_EMAIL" ng-model="FORM.MI_EMAIL"></td>

                              <td>Contact No..:<input type="text" name="MI_CONTACT" ng-model="FORM.MI_CONTACT"></td>
                             
                            </tr>

                             
                      
                            <tr>
                              <th>Address of Member</th>
                            </tr>
                            <tr>
                              <td>No. Street:<input type="text" name="AM_NO_STREET" ng-model="FORM.AM_NO_STREET"></td>

                              <td>Municipality City:<input type="text" name="AM_MUNICIPALITY_CITY" ng-model="FORM.AM_MUNICIPALITY_CITY"></td>

                            </tr>

                             <tr>
                              <td>Barangay:<input type="text" name="AM_BARANGAY" ng-model="FORM.AM_BARANGAY"></td>

                              <td>Province:<input type="text" name="AM_PROVINCE" ng-model="FORM.AM_PROVINCE"></td>

                              <td>Zipcode:<input type="text" name="AM_ZIPCODE" ng-model="FORM.AM_ZIPCODE"></td>

                            </tr>
                             <tr>
                              <th>Patient's Employer</th>
                            </tr>
                            
                               <tr>
                              <td>Employer's Name:<input type="text" name="PHIC_PE_NAME" ng-model="FORM.PHIC_PE_NAME"></td>
                              <td>Contact No:<input type="text" name="PHIC_PE_CONTACT_NO" ng-model="FORM.PHIC_PE_CONTACT_NO"></td>
                              <td>PEN (PHIC Employer Number):<input type="text" name="PHIC_PE_PIN" ng-model="FORM.PHIC_PE_PIN"></td>

                            </tr>
                            <tr>
                             

                            </tr>
                            <tr> </tr>


                          </table> 
            </section>
          </div>
                 
              <button type="submit" class="button" ><span>Submit Patient </span>  </button>
            
          </div>




        </form>


  </div>



  </body>
  </html>

    

      



       