
  <html ng-app="MyApplication">
  <head>
  <script src="<?php echo base_url('asset/angularjs/angular.min.js')?>"></script>
  <script src="<?php echo base_url('asset/angularjs/angular-sanitize.min.js') ?>"></script>
  <script src="<?php echo base_url('folder/patients.controller.js')?>"></script>
  <link rel="stylesheet" href="<?php echo base_url('folder/style.css')?>">
<script type="text/javascript">
  var BASEURL='<?php echo base_url();?>'; 
</script> 


  </head>
  
  <body>
    <div class="header1">
      <h1>Pre Registration</h1>
      <a href="<?php echo base_url('patients/log-out');?>">Logout</a>
    

<div ng-controller="Controller1" ng-init="searchform()" class="main"> 

     
<div>
  <a class="button" href="<?php echo base_url('patients/new-patient');?>"> Add Patient</a>
  <div class="search">

      <div>
        
        <input type="text" name="search" ng-model="SEARCHPATIENT.LASTNAME"required="required" placeholder="Search patients.....">
      </div>
      
  </div>
</div>



<form >

        



<div class="table-box">
      <table cellpadding="20">
          
            <thead>
               <tr>
                <th>ID</th>
                <th>LASTNAME</th>
                <th>FIRSTNAME</th>
                <th>MIDDLENAME</th>
                <th>SUFFIX</th>
                <th>SEX</th>
                <th>EDIT</th>
                <th>DELETE</th>
              </tr>
            </thead>

              <tbody id="show_data">
                     <tr ng-repeat="r in data | filter:SEARCHPATIENT">
                      <td>{{r.id}}</td>
                       <td>{{r.LASTNAME}}</td>
                       <td>{{r.FIRSTNAME}}</td>
                       <td>{{r.MIDDLENAME}}</td> 
                       <td>{{r.SUFFIX}}</td>
                       <td>{{r.SEX}}</td>
                       <td>
                       <a class="button2"  href="<?php echo base_url('patients/edit-patient/');?>{{r.id}}">Edit</a>
                      </td>
                      <td>
                       <a class="button3"  href="<?php echo base_url('patients/delete-patient/');?>{{r.id}}">Delete</a>
                      </td>
                     </tr>

              </tbody>
                            
        </table>
  </div>

     
  </div>
  </div> 

  </body>
  </html>




      
