<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('page_login');
		$this->load->view('page_patient_registrationdatas');
		$this->load->view('page_patient_registration_data');
		$this->load->view('page_patient_registration');



	}
	public function submit_form_registration ()
	{
		$this->load->model('M_patients');
		$this->M_patients->submit_form_registration();

	}

	 public function new_patient()
	{
   
 	 $this->load->view('page_patient_registration',array('id'=>0));
  	}

  	public function view_patient()
	{
   
 	 $this->load->view('page_patient_registration_data');
  	}

  	public function log_out()
	{
   
 	 $this->load->view('page_login');
  	}

   public function search_patient()
   {
   	$this->load->model('M_patients');
        $data=$this->M_patients->search_patient();
        echo json_encode($data);
    }
 
 	public function edit_patient($pid)
 	{
 		
 		$this->load->view('page_patient_registration',array('id'=>$pid));
	
	}

	 	public function edit_patientdata()
 	{
 		$this->load->model('M_patients');
 		 $data=$this->M_patients->edit_patientdata();
 		 echo json_encode($data);

	}   

 
	public function delete_patientdata()
	{	 
		$this->load->database();
        $this->db->where('id', $id);
		$this->db->delete('patient_information');
		echo json_encode(['success'=>true]);

	}



	 //   public function update_patientdata()
  //   {

  //   	$this->load->model('M_patients');
		// $this->M_patients->update_patientdata($id);
		// $this->load->view('page_patient_registration_data');
 
  //   } 

 //    public function delete_patientdata()
 //    {
	// 	$result = $this->m->delete_patientdata();
	// 	$msg['success'] = false;
	// 	if($result){
	// 		$msg['success'] = true;
	// 	}
	// 	echo json_encode($msg);
	// }

	
}
